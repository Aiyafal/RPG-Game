using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_AnimationTriggers : MonoBehaviour
{
    private Entity entity;
    private Entity_Combat entityCombat;

    protected virtual void Awake()
    {
        entity = GetComponentInParent<Entity>();
        entityCombat = GetComponentInParent<Entity_Combat>();
    }


    private void CurrentStateTrigger()
    {
        //��ȡ��Ҷ���֪ͨ��ǰ״̬��Ҫ�˳�

        entity.CurrentStateAnimationTrigger();
    }

    protected void AttackTrigger()
    {
        entityCombat.PerformAttack();
    }
}
