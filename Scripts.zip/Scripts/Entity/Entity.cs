using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity : MonoBehaviour
{
    public event Action onFlipped;
    public Animator anim { get; private set; }
    public Rigidbody2D rb { get; private set; }

    protected StateMachine stateMachine;

   
    private bool facingright = true;
    public int facingDir { get; private set; } = 1;

   
    [Header("Collision detection")]
    [SerializeField] protected LayerMask whatIsGround;
    [SerializeField] private float groundCheckDistance;
    [SerializeField] private float wallCheckDistance;
    [SerializeField] private Transform groundCheck;    
    [SerializeField] private Transform primaryWallCheck;
    [SerializeField] private Transform secondaryWallCheck;


    public Coroutine knockbackCo;
    private bool isKnocked;


    public bool groundDetected { get; private set; }
    public bool wallDetected { get; private set; }

    protected virtual void Awake()
    {
        anim = GetComponentInChildren<Animator>();
        rb = GetComponent<Rigidbody2D>();

        stateMachine = new StateMachine();
    }

   
    protected virtual void Start()
    {
       
    }

    protected virtual void Update()
    {
        HandleCollisionDetectin();
        stateMachine.UpdateActiveState();
    }

    public void ReciveKnockback(Vector2 knockback , float duration)
    {
        if (knockbackCo != null)
            StopCoroutine(knockbackCo);
       
        knockbackCo = StartCoroutine(KnockbackCo(knockback, duration));
    }


    private IEnumerator KnockbackCo(Vector2 knockback ,float duration)
    {
        isKnocked = true;
        rb.velocity = knockback;

        yield return new WaitForSeconds(duration);

        rb.velocity = Vector2.zero;
        isKnocked = false;
    }
   

    public void CurrentStateAnimationTrigger()
    {
        stateMachine.currentstate.AnimationTrigger();
    }

    public virtual void EnitityDeath()
    {

    }


    public void SetVeloicity(float xVelocity, float yVelocity)
    {

        if (isKnocked)
            return;
        
        
        rb.velocity = new Vector2(xVelocity, yVelocity);
        HandleFlip(xVelocity);
    }

    public void HandleFlip(float xVelocity)
    {
        if (xVelocity > 0 && facingright == false)
            Flip();
        else if (xVelocity < 0 && facingright)
            Flip();

        onFlipped?.Invoke();
    }

    public void Flip()
    {
        transform.Rotate(0, 180, 0);
        facingright = !facingright;
        facingDir = facingDir * -1;
    }

    private void HandleCollisionDetectin()
    {
        groundDetected = Physics2D.Raycast(groundCheck.position, Vector2.down, groundCheckDistance, whatIsGround);

        if (secondaryWallCheck != null)
            wallDetected = Physics2D.Raycast(primaryWallCheck.position, Vector2.right * facingDir, wallCheckDistance, whatIsGround)
                    && Physics2D.Raycast(secondaryWallCheck.position, Vector2.right * facingDir, wallCheckDistance, whatIsGround);
        else
            wallDetected = Physics2D.Raycast(primaryWallCheck.position, Vector2.right * facingDir, wallCheckDistance, whatIsGround);
    }

    protected virtual void OnDrawGizmos()
    {
        Gizmos.DrawLine(groundCheck.position, groundCheck.position + new Vector3(0, -groundCheckDistance));
        Gizmos.DrawLine(primaryWallCheck.position, primaryWallCheck.position + new Vector3(wallCheckDistance * facingDir, 0));
        
        if(secondaryWallCheck!=null)
            Gizmos.DrawLine(secondaryWallCheck.position, secondaryWallCheck.position + new Vector3(wallCheckDistance * facingDir, 0));
    }
}
