using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class EntityState 
{
    protected StateMachine stateMachine;
    protected string animBoolName;

    protected Animator anim;
    protected Rigidbody2D rb;

    protected float stateTimer;
    protected bool triggerCalled;  

    public EntityState(StateMachine stateMachine, string animBoolName)
    {
        this.stateMachine = stateMachine;
        this.animBoolName = animBoolName;
    }

    public virtual void Enter()
    {
        anim.SetBool(animBoolName, true);
        triggerCalled = false;

        //ÿ�θ���״̬ʱ��enter�������ᱻ����
        // Debug.Log("I enter " + animBoolName);
    }

    public virtual void Update()
    {
        stateTimer -= Time.deltaTime;
        UpdapateAnimationParameters();
    }

    public virtual void Exit()
    {
        anim.SetBool(animBoolName, false);

        //ÿ���˳�״̬��������״̬ʱ��exit�������ᱻ����
        //Debug.Log("I exit " + animBoolName);
    }

    public void AnimationTrigger()
    {
        triggerCalled = true;
    }

    public virtual void UpdapateAnimationParameters()
    {

    }
}
