using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Health : Entity_Health
{
    private Enemy enemy => GetComponent<Enemy>();

    public override void TakeDamage(float damage, Transform damageDealer)
    {
        base.TakeDamage(damage, damageDealer);

        if (isDead)
            return;  //��ֹһ����ɱ����Ȼ����ս��״̬


        if (damageDealer.GetComponent<Player>() != null)
            enemy.TrayEnterBattleState(damageDealer);
        
    }
}
