using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_JumpAttackState : PlayerState
{
    private bool touchedGround;

    public Player_JumpAttackState(Player player, StateMachine stateMachine, string animBoolName) : base(player, stateMachine, animBoolName)
    {
    }
    public override void Enter()
    {
        base.Enter();
        touchedGround = false;

        player.SetVeloicity(player.jumpAttackVelocity.x*player.facingDir, player.jumpAttackVelocity.y);
    }


    public override void Update()
    {
        base.Update();

        if(player.groundDetected && touchedGround==false)
        {
            touchedGround = true;
            anim.SetTrigger("jumpAttackTrigger");
            player.SetVeloicity(0, rb.velocity.y);
        }

        if (triggerCalled && player.groundDetected)
            stateMachine.ChangeState(player.idleState);
    }

}
